// VERSION _must_ be \d.\d+
#define VERSION "9.21"
#define DATE	"2014-12-31"
